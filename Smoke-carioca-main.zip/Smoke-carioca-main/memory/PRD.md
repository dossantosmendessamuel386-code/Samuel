# Smoke Carioca — Site Vitrine

## Problem statement
Cliente quer apresentar para o Smoke Carioca (Bar e Restaurante em Higienópolis, RJ) um site profissional. Site de vitrine — sem reservas, sem pedidos online. Deve mostrar a cara do bar, cardápios completos e informações de localização/contato.

## Architecture
- Frontend único em React (vitrine estática), sem dependência de backend customizado
- Tailwind + shadcn UI components base
- Componentes: Navbar, Hero, About, MenuSection (tabs), Gallery, Reviews, Visit, Footer, WhatsAppFloat
- Dados do cardápio em `/app/frontend/src/data/menu.js` extraídos das fotos enviadas pelo cliente
- Imagem real do estabelecimento usada no Hero e em About
- Google Maps embed na seção Visite
- Link direto para WhatsApp (21) 99104-7316

## Implementado (dez/2025)
- Hero imersivo com foto real do bar, headline "Smoke Carioca" + tagline carioca
- Seção Sobre com colagem de fotos e badge 4,9 estrelas
- Cardápio completo em tabs (Burguers, Bebidas, Destilados, Tabacaria) — tudo extraído fielmente das fotos
- Galeria com 7 imagens
- Avaliações do Google (Mariana, Lukitas, Elisangela, agregada)
- Mapa Google embutido + horários reais (qua-dom) + contato
- Footer institucional + botão flutuante WhatsApp
- Tema visual: preto/cream/burgundy/amber + Playfair Display + Inter (fiel às artes do cardápio do cliente)

## P1 backlog
- Adicionar link real do Instagram do estabelecimento
- Botão "Reservar mesa" via WhatsApp com mensagem pré-definida (caso o cliente queira)
- Carrossel de eventos/pagode com agenda semanal
- Versão PT-EN para turistas

## P2 backlog
- Sistema admin para o dono editar preços
- Cardápio em PDF para download/impressão
- Integração Google Reviews automática (puxar avaliações live)
