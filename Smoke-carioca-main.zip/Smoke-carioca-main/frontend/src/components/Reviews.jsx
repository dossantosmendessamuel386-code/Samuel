import React from "react";
import { reviews, info } from "../data/menu";

export const Reviews = () => {
  return (
    <section id="avaliacoes" className="relative py-28 lg:py-36 smoke-radial bg-grain" data-testid="reviews-section">
      <div className="relative z-10 max-w-7xl mx-auto px-5 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10 lg:gap-16">
          <div className="lg:col-span-4">
            <span className="divider-ornament text-[10px] uppercase tracking-[0.4em] text-[var(--sc-amber)]">
              <i className="fa-brands fa-google" /> Avaliações
            </span>
            <h2 className="mt-6 font-display text-5xl lg:text-6xl font-bold text-[var(--sc-cream)] leading-[1.05]">
              <span className="italic text-[var(--sc-amber)]">4,9</span> de cinco
            </h2>
            <p className="mt-5 text-[var(--sc-cream-2)]/70 text-[15px] leading-relaxed">
              Quem vem ao Smoke volta — e conta para os amigos. Veja o que os clientes andam dizendo no Google.
            </p>

            {/* Big rating card */}
            <div className="mt-10 border border-[var(--sc-line-strong)] rounded-md p-7 bg-[#0d0a06]/70 backdrop-blur">
              <div className="flex items-center gap-4">
                <div className="font-display text-6xl font-black text-[var(--sc-cream)]">{info.rating.toString().replace(".", ",")}</div>
                <div>
                  <div className="flex gap-1">
                    {[...Array(5)].map((_, i) => (
                      <i key={i} className="fa-solid fa-star text-[var(--sc-amber)] text-sm" />
                    ))}
                  </div>
                  <div className="text-[11px] uppercase tracking-[0.25em] text-[var(--sc-cream-2)]/60 mt-1.5">
                    {info.totalReviews} avaliações
                  </div>
                </div>
              </div>
              <div className="mt-5 space-y-1.5">
                {[5, 4, 3, 2, 1].map((star) => {
                  const widths = { 5: 95, 4: 4, 3: 1, 2: 0, 1: 0 };
                  return (
                    <div key={star} className="flex items-center gap-3">
                      <span className="text-[10px] text-[var(--sc-cream-2)]/60 w-3">{star}</span>
                      <div className="flex-1 h-1.5 bg-[var(--sc-line)] rounded-full overflow-hidden">
                        <div
                          className="h-full bg-[var(--sc-amber)]"
                          style={{ width: `${widths[star]}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="lg:col-span-8 grid sm:grid-cols-2 gap-5">
            {reviews.map((r, i) => (
              <article
                key={i}
                data-testid={`review-${i}`}
                className="relative border border-[var(--sc-line-strong)] rounded-md p-7 bg-[#0d0a06]/40 hover:border-[var(--sc-amber)]/60 hover:bg-[#0d0a06]/60 transition-all"
              >
                <div className="absolute -top-3 -left-2 font-display text-7xl text-[var(--sc-burgundy)] leading-none select-none">"</div>
                <div className="flex gap-1 mb-3">
                  {[...Array(r.nota)].map((_, k) => (
                    <i key={k} className="fa-solid fa-star text-[var(--sc-amber)] text-xs" />
                  ))}
                </div>
                <p className="text-[15px] text-[var(--sc-cream)] leading-relaxed font-light">
                  {r.texto}
                </p>
                <div className="mt-5 flex items-center gap-3 pt-4 border-t border-[var(--sc-line)]">
                  <div className="w-10 h-10 rounded-full bg-[var(--sc-burgundy)]/40 border border-[var(--sc-amber)]/40 flex items-center justify-center font-display text-[var(--sc-cream)] font-bold">
                    {r.nome.charAt(0)}
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-[var(--sc-cream)]">{r.nome}</div>
                    <div className="text-[10px] uppercase tracking-[0.25em] text-[var(--sc-cream-2)]/50">{r.quando}</div>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Reviews;
