import React from "react";
import { SmokeLogo } from "./SmokeLogo";
import { info } from "../data/menu";

export const Footer = () => {
  return (
    <footer className="relative border-t border-[var(--sc-line)] bg-[#0a0907] pt-20 pb-10" data-testid="footer">
      <div className="max-w-7xl mx-auto px-5 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10 lg:gap-16 pb-12">
          <div className="lg:col-span-5">
            <div className="flex items-center gap-3">
              <SmokeLogo size={48} color="var(--sc-cream)" />
              <div>
                <div className="font-display text-3xl font-bold text-[var(--sc-cream)]">
                  Smoke <span className="text-[var(--sc-amber)] italic">Carioca</span>
                </div>
                <div className="text-[10px] uppercase tracking-[0.3em] text-[var(--sc-cream-2)]/60">
                  {info.subtitulo}
                </div>
              </div>
            </div>
            <p className="mt-6 text-sm text-[var(--sc-cream-2)]/60 max-w-md leading-relaxed">
              Seu ponto de encontro em Higienópolis para quem curte hambúrguer artesanal,
              drinks autorais, narguilé e o melhor pagode da Zona Norte.
            </p>
          </div>

          <div className="lg:col-span-3">
            <h4 className="text-[10px] uppercase tracking-[0.3em] text-[var(--sc-amber)] mb-4">Navegação</h4>
            <ul className="space-y-2.5 text-sm">
              {[
                { l: "Sobre a casa", h: "#sobre" },
                { l: "Cardápio", h: "#cardapio" },
                { l: "Galeria", h: "#galeria" },
                { l: "Avaliações", h: "#avaliacoes" },
                { l: "Visite", h: "#visite" },
              ].map((x) => (
                <li key={x.h}>
                  <a href={x.h} className="text-[var(--sc-cream-2)]/70 hover:text-[var(--sc-amber)] transition-colors">
                    {x.l}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="lg:col-span-4">
            <h4 className="text-[10px] uppercase tracking-[0.3em] text-[var(--sc-amber)] mb-4">Contato</h4>
            <ul className="space-y-3 text-sm text-[var(--sc-cream-2)]/75">
              <li className="flex items-start gap-3">
                <i className="fa-solid fa-location-dot text-[var(--sc-amber)] mt-1" />
                <span>{info.endereco}</span>
              </li>
              <li>
                <a href={`tel:+55${info.whatsapp}`} className="flex items-center gap-3 hover:text-[var(--sc-amber)]">
                  <i className="fa-solid fa-phone text-[var(--sc-amber)]" />
                  {info.telefone}
                </a>
              </li>
              <li>
                <a
                  href={`https://wa.me/${info.whatsapp}`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-3 hover:text-[var(--sc-amber)]"
                >
                  <i className="fa-brands fa-whatsapp text-[var(--sc-amber)]" />
                  WhatsApp
                </a>
              </li>
            </ul>
            <div className="mt-6 flex gap-3">
              <SocialIcon icon="fa-brands fa-instagram" />
              <SocialIcon icon="fa-brands fa-whatsapp" href={`https://wa.me/${info.whatsapp}`} />
              <SocialIcon icon="fa-brands fa-google" />
              <SocialIcon icon="fa-brands fa-facebook-f" />
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-[var(--sc-line)] flex flex-wrap items-center justify-between gap-4 text-[11px] uppercase tracking-[0.2em] text-[var(--sc-cream-2)]/40">
          <span>© {new Date().getFullYear()} Smoke Carioca · Todos os direitos reservados</span>
          <span>Higienópolis · Rio de Janeiro · Brasil</span>
        </div>
      </div>
    </footer>
  );
};

const SocialIcon = ({ icon, href = "#" }) => (
  <a
    href={href}
    target={href.startsWith("http") ? "_blank" : undefined}
    rel="noreferrer"
    className="w-10 h-10 rounded-full border border-[var(--sc-line-strong)] flex items-center justify-center text-[var(--sc-cream-2)]/70 hover:border-[var(--sc-amber)] hover:text-[var(--sc-amber)] transition-colors"
  >
    <i className={icon} />
  </a>
);

export default Footer;
