import React from "react";
import { info } from "../data/menu";

export const WhatsAppFloat = () => (
  <a
    href={`https://wa.me/${info.whatsapp}?text=Ol%C3%A1!%20Vim%20pelo%20site%20do%20Smoke%20Carioca.`}
    target="_blank"
    rel="noreferrer"
    aria-label="Falar no WhatsApp"
    data-testid="whatsapp-float"
    className="fixed bottom-6 left-6 z-40 w-14 h-14 rounded-full bg-[#25D366] text-white flex items-center justify-center shadow-2xl border-2 border-white/20 hover:scale-110 transition-transform"
  >
    <i className="fa-brands fa-whatsapp text-2xl" />
    <span className="absolute inset-0 rounded-full border-2 border-[#25D366] animate-ping opacity-50" />
  </a>
);

export default WhatsAppFloat;
