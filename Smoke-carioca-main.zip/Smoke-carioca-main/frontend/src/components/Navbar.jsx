import React, { useEffect, useState } from "react";
import { SmokeLogo } from "./SmokeLogo";
import { Menu, X } from "lucide-react";

const links = [
  { label: "Sobre", href: "#sobre" },
  { label: "Cardápio", href: "#cardapio" },
  { label: "Galeria", href: "#galeria" },
  { label: "Avaliações", href: "#avaliacoes" },
  { label: "Visite", href: "#visite" },
];

export const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      data-testid="navbar"
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-[#0a0907]/85 backdrop-blur-md border-b border-[var(--sc-line)]"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-5 lg:px-10 h-20 flex items-center justify-between">
        <a href="#top" className="flex items-center gap-3 group" data-testid="brand-link">
          <SmokeLogo size={36} color="var(--sc-cream)" className="transition-transform group-hover:rotate-3" />
          <div className="leading-tight">
            <div className="font-display text-[22px] font-bold tracking-wide text-[var(--sc-cream)]">
              Smoke <span className="text-[var(--sc-amber)]">Carioca</span>
            </div>
            <div className="text-[10px] uppercase tracking-[0.32em] text-[var(--sc-cream-2)]/60">
              Higienópolis · RJ
            </div>
          </div>
        </a>

        <nav className="hidden lg:flex items-center gap-9">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              data-testid={`nav-${l.label.toLowerCase()}`}
              className="text-[13px] uppercase tracking-[0.2em] text-[var(--sc-cream-2)]/80 hover:text-[var(--sc-amber)] transition-colors"
            >
              {l.label}
            </a>
          ))}
          <a
            href="#visite"
            className="btn-primary"
            data-testid="nav-cta-button"
          >
            <i className="fa-solid fa-location-dot" />
            Como chegar
          </a>
        </nav>

        <button
          className="lg:hidden text-[var(--sc-cream)] p-2"
          onClick={() => setOpen(!open)}
          data-testid="mobile-menu-toggle"
          aria-label="Menu"
        >
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {open && (
        <div className="lg:hidden bg-[#0a0907]/95 backdrop-blur border-t border-[var(--sc-line)]" data-testid="mobile-menu">
          <div className="px-5 py-6 flex flex-col gap-5">
            {links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className="text-[13px] uppercase tracking-[0.2em] text-[var(--sc-cream-2)]/80 hover:text-[var(--sc-amber)]"
                data-testid={`mobile-nav-${l.label.toLowerCase()}`}
              >
                {l.label}
              </a>
            ))}
            <a href="#visite" onClick={() => setOpen(false)} className="btn-primary self-start" data-testid="mobile-cta">
              <i className="fa-solid fa-location-dot" />
              Como chegar
            </a>
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;
