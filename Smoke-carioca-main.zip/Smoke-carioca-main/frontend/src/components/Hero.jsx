import React from "react";
import { info } from "../data/menu";

const HERO_IMG = "https://customer-assets.emergentagent.com/job_smoke-carioca-bar/artifacts/1xg4j0gf_1.png";

export const Hero = () => {
  return (
    <section
      id="top"
      className="relative min-h-[100svh] w-full overflow-hidden flex items-end"
      data-testid="hero-section"
    >
      {/* Background photo of the bar */}
      <div className="absolute inset-0">
        <img
          src={HERO_IMG}
          alt="Ambiente do Smoke Carioca · mesas de madeira sob luzes amarelas"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/35 to-[#0a0907]" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-transparent to-transparent" />
      </div>

      {/* Smoke puffs */}
      <div className="pointer-events-none absolute bottom-1/3 left-1/4 w-40 h-40 rounded-full bg-white/5 blur-3xl smoke-puff" />
      <div className="pointer-events-none absolute bottom-1/2 right-1/4 w-32 h-32 rounded-full bg-[var(--sc-amber)]/10 blur-3xl smoke-puff" style={{ animationDelay: "2s" }} />

      <div className="relative z-10 w-full max-w-7xl mx-auto px-5 lg:px-10 pb-20 lg:pb-28 pt-32">
        <div className="max-w-3xl fade-up">
          <div className="flex items-center gap-3 mb-6">
            <span className="h-px w-10 bg-[var(--sc-amber)]" />
            <span className="text-[11px] uppercase tracking-[0.4em] text-[var(--sc-amber)] font-semibold">
              Higienópolis · Zona Norte do Rio
            </span>
          </div>

          <h1
            className="font-display text-[clamp(56px,9vw,128px)] font-black leading-[0.92] text-[var(--sc-cream)]"
            data-testid="hero-title"
          >
            Smoke
            <span className="block italic text-[var(--sc-amber)] flicker">
              Carioca
            </span>
          </h1>

          <p className="mt-8 text-lg lg:text-xl text-[var(--sc-cream-2)]/80 max-w-2xl leading-relaxed">
            Bar, restaurante e tabacaria onde a noite carioca encontra
            <span className="text-[var(--sc-amber)]"> hambúrgueres artesanais</span>,
            <span className="text-[var(--sc-amber)]"> drinks autorais</span> e
            <span className="text-[var(--sc-amber)]"> narguilé premium</span> — embalada
            por bom pagode e luzes que pedem para ficar.
          </p>

          <div className="mt-10 flex flex-wrap items-center gap-4">
            <a href="#cardapio" className="btn-primary" data-testid="hero-menu-button">
              <i className="fa-solid fa-utensils" />
              Ver cardápio
            </a>
            <a
              href={`https://wa.me/${info.whatsapp}`}
              target="_blank"
              rel="noreferrer"
              className="btn-ghost"
              data-testid="hero-whatsapp-button"
            >
              <i className="fa-brands fa-whatsapp text-base" />
              WhatsApp
            </a>
          </div>

          {/* Stats strip */}
          <div className="mt-14 grid grid-cols-3 gap-6 max-w-xl">
            <Stat value="4,9" label="Avaliação Google" sub="49 avaliações" />
            <Stat value="R$ 40-60" label="Ticket médio" sub="por pessoa" />
            <Stat value="Qua-Dom" label="Funcionamento" sub="a partir das 19h" />
          </div>
        </div>
      </div>

      {/* Bottom info bar */}
      <div className="absolute bottom-0 inset-x-0 z-10 border-t border-[var(--sc-line)] bg-[#0a0907]/70 backdrop-blur">
        <div className="max-w-7xl mx-auto px-5 lg:px-10 py-4 flex flex-wrap items-center justify-between gap-4 text-[12px] uppercase tracking-[0.2em] text-[var(--sc-cream-2)]/70">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[var(--sc-amber)] animate-pulse" />
            <span>Av. dos Democráticos, 811 — Higienópolis</span>
          </div>
          <div className="hidden md:flex items-center gap-6">
            {info.servicos.map((s, i) => (
              <span key={i} className="flex items-center gap-2">
                <i className="fa-solid fa-check text-[var(--sc-amber)] text-[10px]" />
                {s}
              </span>
            ))}
          </div>
          <a href={`tel:+55${info.whatsapp}`} className="text-[var(--sc-amber)] hover:underline">
            {info.telefone}
          </a>
        </div>
      </div>
    </section>
  );
};

const Stat = ({ value, label, sub }) => (
  <div>
    <div className="font-display text-3xl lg:text-4xl text-[var(--sc-cream)] font-bold">{value}</div>
    <div className="text-[10px] uppercase tracking-[0.25em] text-[var(--sc-amber)] mt-1">{label}</div>
    <div className="text-[11px] text-[var(--sc-cream-2)]/55 mt-0.5">{sub}</div>
  </div>
);

export default Hero;
