import React, { useState } from "react";
import { bebidas, burguers, destilados, tabacaria } from "../data/menu";

const TABS = [
  { id: "burguers", label: "Burguers", icon: "fa-burger" },
  { id: "bebidas", label: "Bebidas", icon: "fa-beer-mug-empty" },
  { id: "destilados", label: "Destilados", icon: "fa-whiskey-glass" },
  { id: "tabacaria", label: "Tabacaria", icon: "fa-smoking" },
];

const formatBRL = (n) => `R$ ${n.toString().replace(".", ",")}`;

const PriceTag = ({ value, label, dark }) => (
  <div className="text-right">
    <div className={`font-display font-bold text-lg ${dark ? "text-[var(--sc-cream)]" : "text-[var(--sc-burgundy)]"}`}>
      {formatBRL(value)}
    </div>
    {label && (
      <div className={`text-[9px] uppercase tracking-[0.2em] ${dark ? "text-[var(--sc-cream-2)]/55" : "text-[#7a4138]"}`}>
        {label}
      </div>
    )}
  </div>
);

const Section = ({ title, dark, children, icon }) => (
  <div className="mb-10 last:mb-0">
    <div className="flex items-center gap-3 mb-5">
      {icon && (
        <i
          className={`fa-solid ${icon} text-base ${
            dark ? "text-[var(--sc-amber)]" : "text-[var(--sc-burgundy)]"
          }`}
        />
      )}
      <h3
        className={`font-display text-2xl lg:text-3xl font-bold tracking-wide ${
          dark ? "text-[var(--sc-cream)]" : "text-[var(--sc-burgundy)]"
        }`}
      >
        {title}
      </h3>
      <div
        className={`flex-1 h-px ${
          dark ? "bg-[var(--sc-line)]" : "bg-[var(--sc-burgundy)]/25"
        }`}
      />
    </div>
    {children}
  </div>
);

const Item = ({ nome, desc, badge, right, dark }) => (
  <div
    className={`flex justify-between items-start gap-6 py-3 border-b last:border-0 ${
      dark ? "border-[var(--sc-line)]" : "border-[#7a1f25]/15"
    }`}
  >
    <div className="flex-1 min-w-0">
      <div className="flex items-center gap-2 flex-wrap">
        <h4 className={`font-display text-lg font-semibold ${dark ? "text-[var(--sc-cream)]" : "text-[#2c1a18]"}`}>
          {nome}
        </h4>
        {badge && (
          <span
            className={`text-[9px] uppercase tracking-[0.18em] px-2 py-0.5 rounded-sm border ${
              dark
                ? "border-[var(--sc-amber)] text-[var(--sc-amber)]"
                : "border-[var(--sc-burgundy)] text-[var(--sc-burgundy)]"
            }`}
          >
            <i className="fa-solid fa-star mr-1 text-[8px]" /> {badge}
          </span>
        )}
      </div>
      {desc && (
        <p className={`mt-1.5 text-[13px] leading-relaxed ${dark ? "text-[var(--sc-cream-2)]/65" : "text-[#5a3c34]"}`}>
          {desc}
        </p>
      )}
    </div>
    <div className="shrink-0">{right}</div>
  </div>
);

// === Tab content components ===
const BurguersContent = () => (
  <div className="menu-card rounded-lg p-8 lg:p-12 paper-bg" data-testid="menu-burguers">
    <div className="text-center mb-8">
      <div className="text-[10px] uppercase tracking-[0.4em] text-[var(--sc-burgundy)]/70">Cardápio</div>
      <h3 className="font-display text-5xl font-black text-[var(--sc-burgundy)] tracking-wide">BURGUERS</h3>
      <div className="mt-2 text-[11px] tracking-[0.3em] text-[#7a4138]">— pão brioche · australiano · blends 150g —</div>
    </div>
    <div className="grid lg:grid-cols-2 gap-x-12">
      {burguers.map((b, i) => (
        <Item
          key={i}
          nome={b.nome}
          desc={b.desc}
          badge={b.badge}
          right={<PriceTag value={b.preco} label={b.combo ? "+ combo" : null} />}
        />
      ))}
    </div>
  </div>
);

const BebidasContent = () => (
  <div className="menu-card rounded-lg p-8 lg:p-12 paper-bg" data-testid="menu-bebidas">
    <div className="text-center mb-8">
      <div className="text-[10px] uppercase tracking-[0.4em] text-[var(--sc-burgundy)]/70">Cardápio</div>
      <h3 className="font-display text-5xl font-black text-[var(--sc-burgundy)] tracking-wide">BEBIDAS</h3>
    </div>
    <div className="grid lg:grid-cols-2 gap-x-12">
      <div>
        <Section title="Não Alcoólicas" icon="fa-glass-water">
          {bebidas.naoAlcoolicas.map((b, i) => (
            <Item key={i} nome={b.nome} right={<PriceTag value={b.preco} />} />
          ))}
        </Section>
        <Section title="Chopp" icon="fa-beer-mug-empty">
          {bebidas.chopp.map((b, i) => (
            <Item key={i} nome={b.nome} desc={b.desc} right={<PriceTag value={b.preco} />} />
          ))}
        </Section>
      </div>
      <div>
        <Section title="Alcoólicas" icon="fa-bottle-droplet">
          <div className="flex justify-end gap-10 text-[10px] uppercase tracking-[0.18em] text-[var(--sc-burgundy)] font-bold mb-1">
            <span className="w-12 text-right">Und.</span>
            <span className="w-14 text-right">Balde 5</span>
          </div>
          {bebidas.alcoolicas.map((b, i) => (
            <Item
              key={i}
              nome={b.nome}
              desc={b.desc}
              right={
                <div className="flex gap-10">
                  <PriceTag value={b.und} />
                  <PriceTag value={b.balde} />
                </div>
              }
            />
          ))}
        </Section>
        <Section title="Licores" icon="fa-wine-bottle">
          <div className="flex justify-end gap-10 text-[10px] uppercase tracking-[0.18em] text-[var(--sc-burgundy)] font-bold mb-1">
            <span className="w-12 text-right">Dose</span>
            <span className="w-16 text-right">Garrafa</span>
          </div>
          {bebidas.licores.map((b, i) => (
            <Item
              key={i}
              nome={b.nome}
              right={
                <div className="flex gap-10">
                  <div className="w-12 text-right">
                    {b.dose ? <PriceTag value={b.dose} /> : <span className="text-sm text-[#7a4138]">—</span>}
                  </div>
                  <div className="w-16 text-right"><PriceTag value={b.garrafa} /></div>
                </div>
              }
            />
          ))}
        </Section>
      </div>
    </div>
  </div>
);

const DestiladosContent = () => (
  <div className="menu-card rounded-lg p-8 lg:p-12 paper-bg" data-testid="menu-destilados">
    <div className="text-center mb-8">
      <div className="text-[10px] uppercase tracking-[0.4em] text-[var(--sc-burgundy)]/70">Cardápio</div>
      <h3 className="font-display text-4xl lg:text-5xl font-black text-[var(--sc-burgundy)] tracking-wide">
        COMBOS DE DESTILADO
      </h3>
      <div className="mt-2 text-[11px] tracking-[0.25em] text-[#7a4138]">
        — combos servidos com 5 Red Bull + 5 gelos de sabor/coco —
      </div>
    </div>
    <div className="grid lg:grid-cols-2 gap-x-12">
      <div>
        <Section title="Gin" icon="fa-martini-glass">
          {destilados.gin.map((b, i) => (
            <Item key={i} nome={b.nome} desc={b.desc} right={<PriceTag value={b.preco} />} />
          ))}
        </Section>
        <Section title="Vodka" icon="fa-glass-water-droplet">
          {destilados.vodka.map((b, i) => (
            <Item key={i} nome={b.nome} desc={b.desc} badge={b.badge} right={<PriceTag value={b.preco} />} />
          ))}
        </Section>
        <Section title="Copão Individual" icon="fa-mug-saucer">
          {destilados.copao.map((b, i) => (
            <Item key={i} nome={b.nome} right={<PriceTag value={b.preco} />} />
          ))}
        </Section>
      </div>
      <div>
        <Section title="Whisky" icon="fa-whiskey-glass">
          {destilados.whisky.map((b, i) => (
            <Item key={i} nome={b.nome} desc={b.desc} right={<PriceTag value={b.preco} />} />
          ))}
        </Section>
      </div>
    </div>
  </div>
);

const TabacariaContent = () => (
  <div className="menu-card-dark rounded-lg p-8 lg:p-12" data-testid="menu-tabacaria">
    <div className="text-center mb-8">
      <div className="text-[10px] uppercase tracking-[0.4em] text-[var(--sc-amber)]">Cardápio</div>
      <h3 className="font-display text-5xl font-black text-[var(--sc-cream)] tracking-wide">TABACARIA</h3>
      <div className="mt-2 text-[11px] tracking-[0.3em] text-[var(--sc-cream-2)]/60">
        — narguilé · essências · acessórios —
      </div>
    </div>
    <div className="grid lg:grid-cols-2 gap-x-12">
      <div>
        <Section dark title="Sessão Narguilé" icon="fa-smoking">
          {tabacaria.sessao.map((b, i) => (
            <Item key={i} dark nome={b.nome} desc={b.desc} right={<PriceTag dark value={b.preco} />} />
          ))}
        </Section>
        <Section dark title="Monte seu Narg." icon="fa-screwdriver-wrench">
          {tabacaria.monteSeu.map((b, i) => (
            <Item key={i} dark nome={b.nome} right={<PriceTag dark value={b.preco} />} />
          ))}
        </Section>
        <Section dark title="Essências" icon="fa-leaf">
          <p className="text-[11px] uppercase tracking-[0.25em] text-[var(--sc-amber)] mb-2">Consulte os sabores</p>
          {tabacaria.essencias.map((b, i) => (
            <Item key={i} dark nome={b.nome} right={<PriceTag dark value={b.preco} />} />
          ))}
        </Section>
        <Section dark title="Cigarros" icon="fa-fire-flame-simple">
          {tabacaria.cigarros.map((b, i) => (
            <Item key={i} dark nome={b.nome} right={<PriceTag dark value={b.preco} />} />
          ))}
        </Section>
      </div>
      <div>
        <Section dark title="Outros" icon="fa-box-open">
          {tabacaria.outros.map((b, i) => (
            <Item key={i} dark nome={b.nome} right={<PriceTag dark value={b.preco} />} />
          ))}
        </Section>
      </div>
    </div>
  </div>
);

export const MenuSection = () => {
  const [active, setActive] = useState("burguers");

  return (
    <section id="cardapio" className="relative py-28 lg:py-36 bg-[var(--sc-bg-2)] bg-grain" data-testid="menu-section">
      <div className="absolute inset-x-0 top-0 h-px gold-line" />
      <div className="relative z-10 max-w-7xl mx-auto px-5 lg:px-10">
        <div className="text-center mb-12">
          <span className="divider-ornament text-[10px] uppercase tracking-[0.4em] text-[var(--sc-amber)]">
            <i className="fa-solid fa-utensils" /> Cardápio
          </span>
          <h2 className="mt-6 font-display text-5xl lg:text-7xl font-bold text-[var(--sc-cream)]">
            O melhor da casa <span className="italic text-[var(--sc-amber)]">à mesa</span>
          </h2>
          <p className="mt-4 text-[var(--sc-cream-2)]/65 max-w-2xl mx-auto">
            Quatro mundos em uma só noite — burguers artesanais, bebidas geladas, destilados premium e a melhor seleção de tabacaria do bairro.
          </p>
        </div>

        {/* Tabs */}
        <div className="flex flex-wrap justify-center gap-3 mb-12 menu-tabs" data-testid="menu-tabs">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setActive(t.id)}
              data-state={active === t.id ? "active" : "inactive"}
              data-testid={`tab-${t.id}`}
              className="flex items-center gap-2 px-6 py-3 rounded-full border border-[var(--sc-line-strong)] text-[12px] uppercase tracking-[0.2em] text-[var(--sc-cream-2)]/75 hover:border-[var(--sc-amber)] hover:text-[var(--sc-amber)] transition-all duration-200"
            >
              <i className={`fa-solid ${t.icon}`} />
              {t.label}
            </button>
          ))}
        </div>

        <div key={active} className="fade-up">
          {active === "burguers" && <BurguersContent />}
          {active === "bebidas" && <BebidasContent />}
          {active === "destilados" && <DestiladosContent />}
          {active === "tabacaria" && <TabacariaContent />}
        </div>

        <div className="mt-10 text-center text-[11px] uppercase tracking-[0.3em] text-[var(--sc-cream-2)]/40">
          * Preços sujeitos a alteração · Cardápio atualizado pela casa
        </div>
      </div>
    </section>
  );
};

export default MenuSection;
