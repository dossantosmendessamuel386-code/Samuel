import React from "react";

const photos = [
  {
    src: "https://customer-assets.emergentagent.com/job_smoke-carioca-bar/artifacts/1xg4j0gf_1.png",
    label: "Ambiente",
    span: "lg:col-span-2 lg:row-span-2",
  },
  {
    src: "https://images.unsplash.com/photo-1514933651103-005eec06c04b?w=800&q=80",
    label: "Drinks autorais",
    span: "",
  },
  {
    src: "https://images.unsplash.com/photo-1571805341302-f857308690e3?w=800&q=80",
    label: "Narguilé premium",
    span: "",
  },
  {
    src: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&q=80",
    label: "Hambúrguer artesanal",
    span: "lg:col-span-2",
  },
  {
    src: "https://images.unsplash.com/photo-1572116469696-31de0f17cc34?w=800&q=80",
    label: "Cerveja gelada",
    span: "",
  },
  {
    src: "https://images.unsplash.com/photo-1543007630-9710e4a00a20?w=800&q=80",
    label: "Drinks na chapa",
    span: "",
  },
  {
    src: "https://images.unsplash.com/photo-1552566626-52f8b828add9?w=800&q=80",
    label: "Pagode na casa",
    span: "lg:col-span-2",
  },
];

export const Gallery = () => {
  return (
    <section id="galeria" className="relative py-28 lg:py-36 bg-[var(--sc-bg)] bg-grain" data-testid="gallery-section">
      <div className="relative z-10 max-w-7xl mx-auto px-5 lg:px-10">
        <div className="flex flex-wrap items-end justify-between gap-6 mb-12">
          <div>
            <span className="divider-ornament text-[10px] uppercase tracking-[0.4em] text-[var(--sc-amber)]">
              <i className="fa-solid fa-camera-retro" /> Galeria
            </span>
            <h2 className="mt-6 font-display text-5xl lg:text-6xl font-bold text-[var(--sc-cream)]">
              Um pedacinho da <span className="italic text-[var(--sc-amber)]">noite carioca</span>
            </h2>
          </div>
          <p className="max-w-md text-[var(--sc-cream-2)]/65 text-sm leading-relaxed">
            Da chapa ao copo — passe os olhos pelo ambiente do Smoke e sinta vontade de aparecer hoje à noite.
          </p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 auto-rows-[180px] lg:auto-rows-[220px] gap-3">
          {photos.map((p, i) => (
            <figure
              key={i}
              data-testid={`gallery-item-${i}`}
              className={`relative overflow-hidden rounded-md border border-[var(--sc-line-strong)] group ${p.span}`}
            >
              <img
                src={p.src}
                alt={p.label}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent opacity-80 group-hover:opacity-95 transition-opacity" />
              <figcaption className="absolute bottom-3 left-4 right-4">
                <div className="text-[10px] uppercase tracking-[0.3em] text-[var(--sc-amber)] mb-0.5">
                  Smoke Carioca
                </div>
                <div className="font-display text-lg lg:text-xl text-[var(--sc-cream)]">{p.label}</div>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Gallery;
