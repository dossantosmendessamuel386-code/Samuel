import React from "react";
import { info, horarios } from "../data/menu";

const mapsUrl = "https://www.google.com/maps/search/?api=1&query=Smoke+Carioca+Bar+Restaurante+Av+dos+Democraticos+811";
const mapEmbedSrc =
  "https://www.google.com/maps?q=Av.%20dos%20Democr%C3%A1ticos%2C%20811%20Higien%C3%B3polis%20Rio%20de%20Janeiro&output=embed";

export const Visit = () => {
  return (
    <section id="visite" className="relative py-28 lg:py-36 bg-[var(--sc-bg-2)] bg-grain" data-testid="visit-section">
      <div className="relative z-10 max-w-7xl mx-auto px-5 lg:px-10">
        <div className="text-center mb-14">
          <span className="divider-ornament text-[10px] uppercase tracking-[0.4em] text-[var(--sc-amber)]">
            <i className="fa-solid fa-location-dot" /> Visite
          </span>
          <h2 className="mt-6 font-display text-5xl lg:text-7xl font-bold text-[var(--sc-cream)]">
            Te esperamos <span className="italic text-[var(--sc-amber)]">por aqui</span>
          </h2>
        </div>

        <div className="grid lg:grid-cols-5 gap-8 lg:gap-10">
          {/* Map */}
          <div
            className="lg:col-span-3 relative rounded-md overflow-hidden border border-[var(--sc-line-strong)] min-h-[480px]"
            data-testid="map-container"
          >
            <iframe
              title="Localização Smoke Carioca"
              src={mapEmbedSrc}
              className="absolute inset-0 w-full h-full grayscale-[40%] contrast-[1.1] brightness-[0.85]"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              allowFullScreen
            />
            <div className="absolute bottom-5 left-5 right-5 flex flex-wrap items-center justify-between gap-3 bg-[#0a0907]/85 backdrop-blur border border-[var(--sc-amber)]/40 rounded-md p-4">
              <div>
                <div className="text-[10px] uppercase tracking-[0.3em] text-[var(--sc-amber)]">Endereço</div>
                <div className="text-sm text-[var(--sc-cream)] mt-0.5">{info.endereco}</div>
              </div>
              <a
                href={mapsUrl}
                target="_blank"
                rel="noreferrer"
                className="btn-primary"
                data-testid="open-maps-button"
              >
                <i className="fa-solid fa-diamond-turn-right" />
                Como chegar
              </a>
            </div>
          </div>

          {/* Info */}
          <div className="lg:col-span-2 flex flex-col gap-5">
            {/* Hours */}
            <div className="border border-[var(--sc-line-strong)] rounded-md p-7 bg-[#0d0a06]/60" data-testid="hours-card">
              <div className="flex items-center gap-3 mb-5">
                <i className="fa-solid fa-clock text-[var(--sc-amber)]" />
                <h3 className="font-display text-xl text-[var(--sc-cream)]">Horários</h3>
              </div>
              <ul className="space-y-2.5">
                {horarios.map((h, i) => (
                  <li
                    key={i}
                    className={`flex justify-between items-center text-sm ${
                      h.aberto ? "text-[var(--sc-cream)]" : "text-[var(--sc-cream-2)]/40"
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <span className={`w-1.5 h-1.5 rounded-full ${h.aberto ? "bg-[var(--sc-amber)]" : "bg-[var(--sc-cream-2)]/30"}`} />
                      {h.dia}
                    </span>
                    <span className={h.aberto ? "" : "italic"}>{h.intervalo}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact */}
            <div className="border border-[var(--sc-line-strong)] rounded-md p-7 bg-[#0d0a06]/60" data-testid="contact-card">
              <div className="flex items-center gap-3 mb-5">
                <i className="fa-solid fa-phone text-[var(--sc-amber)]" />
                <h3 className="font-display text-xl text-[var(--sc-cream)]">Contato</h3>
              </div>
              <div className="space-y-3">
                <a
                  href={`tel:+55${info.whatsapp}`}
                  className="flex items-center gap-3 text-[var(--sc-cream)] hover:text-[var(--sc-amber)] transition-colors"
                  data-testid="phone-link"
                >
                  <i className="fa-solid fa-mobile-screen-button text-[var(--sc-amber)]/80 w-4" />
                  <span>{info.telefone}</span>
                </a>
                <a
                  href={`https://wa.me/${info.whatsapp}`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-3 text-[var(--sc-cream)] hover:text-[var(--sc-amber)] transition-colors"
                  data-testid="whatsapp-link"
                >
                  <i className="fa-brands fa-whatsapp text-[var(--sc-amber)]/80 w-4" />
                  <span>WhatsApp · pedidos & dúvidas</span>
                </a>
                <div className="flex items-start gap-3 text-[var(--sc-cream-2)]/75">
                  <i className="fa-solid fa-map-pin text-[var(--sc-amber)]/80 w-4 mt-1" />
                  <span className="text-sm leading-relaxed">{info.plusCode}</span>
                </div>
              </div>

              <div className="mt-6 pt-5 border-t border-[var(--sc-line)] flex flex-wrap gap-2">
                {info.servicos.map((s, i) => (
                  <span
                    key={i}
                    className="text-[10px] uppercase tracking-[0.2em] px-3 py-1.5 rounded-full border border-[var(--sc-amber)]/40 text-[var(--sc-amber)]"
                  >
                    {s}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Visit;
