import React from "react";
import { info } from "../data/menu";

export const About = () => {
  return (
    <section id="sobre" className="relative py-28 lg:py-36 smoke-radial bg-grain" data-testid="about-section">
      <div className="relative z-10 max-w-7xl mx-auto px-5 lg:px-10 grid lg:grid-cols-12 gap-12 lg:gap-16 items-center">
        <div className="lg:col-span-5">
          <span className="divider-ornament text-[10px] uppercase tracking-[0.4em] text-[var(--sc-amber)]">
            <i className="fa-solid fa-fire-flame-curved" /> A casa
          </span>
          <h2 className="mt-6 font-display text-5xl lg:text-6xl font-bold leading-[1.05] text-[var(--sc-cream)]">
            Onde o samba abraça
            <span className="block italic text-[var(--sc-amber)]">a fumaça da noite.</span>
          </h2>
          <p className="mt-8 text-[15px] lg:text-base leading-relaxed text-[var(--sc-cream-2)]/75">
            No coração de Higienópolis, o <strong className="text-[var(--sc-cream)]">Smoke Carioca</strong> é o
            ponto de encontro perfeito para quem busca um bar de verdade: mesa de madeira, cerveja gelada no
            balde, hambúrguer suculento na chapa e narguilé que rola até alta madrugada. Tudo isso ao som do
            melhor pagode e com um atendimento que os clientes não cansam de elogiar.
          </p>

          <div className="mt-10 grid grid-cols-2 gap-4">
            {info.destaques.map((d, i) => (
              <div
                key={i}
                className="border border-[var(--sc-line-strong)] rounded-md p-4 hover:border-[var(--sc-amber)] transition-colors"
                data-testid={`destaque-${i}`}
              >
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-full bg-[var(--sc-burgundy)]/30 border border-[var(--sc-amber)]/40 flex items-center justify-center text-[var(--sc-amber)]">
                    <i className={`fa-solid ${[
                      "fa-music",
                      "fa-burger",
                      "fa-martini-glass-citrus",
                      "fa-smoking",
                    ][i]}`} />
                  </span>
                  <span className="text-sm text-[var(--sc-cream)]">{d}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right column: photo collage */}
        <div className="lg:col-span-7 relative">
          <div className="relative grid grid-cols-6 grid-rows-6 gap-3 h-[560px]">
            <div className="col-span-4 row-span-4 relative rounded-md overflow-hidden border border-[var(--sc-line-strong)] group">
              <img
                src="https://customer-assets.emergentagent.com/job_smoke-carioca-bar/artifacts/1xg4j0gf_1.png"
                alt="Smoke Carioca - mesas com luzes"
                className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <div className="absolute bottom-4 left-5 text-[var(--sc-cream)]">
                <div className="font-display text-2xl">Ambiente</div>
                <div className="text-[11px] uppercase tracking-[0.3em] text-[var(--sc-amber)]">aconchego carioca</div>
              </div>
            </div>

            <div className="col-span-2 row-span-3 relative rounded-md overflow-hidden border border-[var(--sc-line-strong)]">
              <img
                src="https://images.unsplash.com/photo-1558030006-450675393462?w=600&q=80"
                alt="Drinks no balcão"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[var(--sc-burgundy)]/80 via-transparent" />
              <div className="absolute bottom-3 left-4 right-4">
                <div className="font-display text-lg text-[var(--sc-cream)]">Drinks</div>
                <div className="text-[10px] uppercase tracking-[0.25em] text-[var(--sc-amber)]">autorais</div>
              </div>
            </div>

            <div className="col-span-2 row-span-3 relative rounded-md overflow-hidden border border-[var(--sc-line-strong)]">
              <img
                src="https://images.unsplash.com/photo-1571805341302-f857308690e3?w=600&q=80"
                alt="Hookah"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent" />
              <div className="absolute bottom-3 left-4 right-4">
                <div className="font-display text-lg text-[var(--sc-cream)]">Narguilé</div>
                <div className="text-[10px] uppercase tracking-[0.25em] text-[var(--sc-amber)]">premium</div>
              </div>
            </div>

            <div className="col-span-4 row-span-2 relative rounded-md overflow-hidden border border-[var(--sc-line-strong)]">
              <img
                src="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=900&q=80"
                alt="Hambúrguer artesanal"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent" />
              <div className="absolute inset-0 flex items-center px-6">
                <div>
                  <div className="font-display text-xl lg:text-2xl text-[var(--sc-cream)]">Hambúrguer artesanal</div>
                  <div className="text-[10px] uppercase tracking-[0.3em] text-[var(--sc-amber)] mt-1">
                    blends 150g · pão brioche · receitas da casa
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* floating rating badge */}
          <div className="absolute -top-6 -right-2 lg:-right-6 bg-[var(--sc-cream)] text-[#2c1a18] rounded-full w-32 h-32 flex flex-col items-center justify-center shadow-2xl border-4 border-[var(--sc-burgundy)] rotate-[-8deg]">
            <div className="font-display text-4xl font-black leading-none">4,9</div>
            <div className="flex gap-0.5 my-1">
              {[...Array(5)].map((_, i) => (
                <i key={i} className="fa-solid fa-star text-[10px] text-[var(--sc-amber-2)]" />
              ))}
            </div>
            <div className="text-[9px] uppercase tracking-[0.2em] font-bold">49 reviews</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
