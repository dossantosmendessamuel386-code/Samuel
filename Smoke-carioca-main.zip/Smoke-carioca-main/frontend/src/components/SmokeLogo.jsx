import React from "react";

// Smoke Carioca brand mark — narguilé silhouette with smoke trails
export const SmokeLogo = ({ size = 44, color = "currentColor", className = "" }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    {/* smoke wisps */}
    <path
      d="M14 8 C 18 12, 10 16, 16 20"
      stroke={color}
      strokeWidth="1.2"
      strokeLinecap="round"
      opacity="0.55"
    />
    <path
      d="M22 4 C 26 9, 18 13, 24 18"
      stroke={color}
      strokeWidth="1.2"
      strokeLinecap="round"
      opacity="0.45"
    />
    {/* hookah top */}
    <rect x="29" y="14" width="6" height="10" rx="1" fill={color} />
    <path d="M28 22 L36 22 L34 26 L30 26 Z" fill={color} />
    <rect x="30" y="26" width="4" height="6" fill={color} />
    {/* mid */}
    <ellipse cx="32" cy="34" rx="6" ry="2.5" fill={color} />
    <rect x="30" y="34" width="4" height="10" fill={color} />
    {/* base bowl */}
    <path d="M22 44 Q 32 38, 42 44 L 42 54 Q 32 60, 22 54 Z" fill={color} />
    {/* hose */}
    <path
      d="M42 46 C 50 46, 54 50, 50 56 C 47 60, 56 60, 56 54"
      stroke={color}
      strokeWidth="1.6"
      strokeLinecap="round"
      fill="none"
    />
  </svg>
);

export default SmokeLogo;
